<?php 

    define('BASE_DIR',   dirname(__FILE__) . '/'); 
    define('UPLOAD_DIR', BASE_DIR . 'uploaded/'); 
    define('CROP_DIR',   BASE_DIR . 'cropped/'); 

?>
