-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 16, 2017 at 05:07 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mypage1`
--

-- --------------------------------------------------------

--
-- Table structure for table `blocks`
--

CREATE TABLE `blocks` (
  `id` int(11) NOT NULL,
  `page` int(11) NOT NULL DEFAULT '0',
  `block` int(11) NOT NULL DEFAULT '0',
  `type` varchar(20) DEFAULT NULL,
  `xpos` varchar(5) DEFAULT NULL,
  `ypos` varchar(5) DEFAULT NULL,
  `width` varchar(5) DEFAULT NULL,
  `height` varchar(5) DEFAULT NULL,
  `title` text NOT NULL,
  `style_type` varchar(10) DEFAULT NULL,
  `background` varchar(30) DEFAULT NULL,
  `border` varchar(20) DEFAULT NULL,
  `parameter1` text NOT NULL,
  `content` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blocks`
--

INSERT INTO `blocks` (`id`, `page`, `block`, `type`, `xpos`, `ypos`, `width`, `height`, `title`, `style_type`, `background`, `border`, `parameter1`, `content`) VALUES
(3, 1, 2, 'top', '-1', '0', '820', '150', '', '', 'none', '1px solid black;', '', ''),
(2, 1, 3, 'link', '0', '145', '140', '1013', 'Pages', 'leftside1', '#CCCCCC', '1px solid black;', '', 'a:3:{s:4:"link";a:1:{i:0;s:16:"index.php?page=1";}s:5:"words";a:1:{i:0;s:7:"My Page";}s:7:"new_tab";a:14:{i:0;s:3:"off";i:1;s:3:"off";i:2;s:3:"off";i:3;s:3:"off";i:4;s:3:"off";i:5;s:3:"off";i:6;s:3:"off";i:7;s:3:"off";i:8;s:3:"off";i:9;s:3:"off";i:10;s:3:"off";i:11;s:3:"off";i:12;s:3:"off";i:13;s:3:"off";}}'),
(7, 1, 0, 'page', '', '', '', '', '', '', '', '', '', 'a:5:{s:10:"background";a:1:{i:1;s:18:"rgb(161, 159, 159)";}s:6:"border";a:1:{i:1;s:0:"";}s:18:"mainbox_background";a:1:{i:1;s:18:"rgb(174, 135, 135)";}s:10:"page_title";s:7:"My Page";s:8:"password";s:0:"";}'),
(8, 1, 1, 'mainbox', '139', '145', '884', '1013', '', '', '#bababa', '1px solid black;', '', 'a:1:{s:11:"block_title";a:3:{i:0;N;i:1;N;i:2;N;}}'),
(9, 1, 0, 'picture_edit_box', '150', '11', '452', '620', '', NULL, NULL, NULL, '', NULL),
(109, 1, 9, 'top_title', '105', '50', '200', '50', '', NULL, NULL, NULL, '', 'This is the title'),
(110, 1, 10, 'general', '396', '40', '348', '66', '', '', 'none', '0;', '', '\r\n<font size="7"><strong><a style="text-decoration:none;" href="?page=1">M</a>y Page</strong></font>'),
(1, 0, 0, NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '', 'a:1:{s:8:"password";s:8:"password";}');

-- --------------------------------------------------------

--
-- Table structure for table `block_types`
--

CREATE TABLE `block_types` (
  `id` int(11) NOT NULL,
  `type` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `block_types`
--

INSERT INTO `block_types` (`id`, `type`) VALUES
(1, 'general'),
(2, 'picture'),
(3, 'blog'),
(4, 'link'),
(5, 'download'),
(6, 'youtube'),
(7, 'top'),
(8, 'rss'),
(9, 'video');

-- --------------------------------------------------------

--
-- Table structure for table `smugmug`
--

CREATE TABLE `smugmug` (
  `id` int(11) NOT NULL,
  `gallery_id` text NOT NULL,
  `gallery_key` text NOT NULL,
  `folder` text NOT NULL,
  `title` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `temp`
--

CREATE TABLE `temp` (
  `id` int(11) NOT NULL,
  `page` varchar(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temp`
--

INSERT INTO `temp` (`id`, `page`) VALUES
(1, '7');

-- --------------------------------------------------------

--
-- Table structure for table `templates`
--

CREATE TABLE `templates` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL DEFAULT '',
  `block` varchar(5) NOT NULL DEFAULT '',
  `type` varchar(20) NOT NULL DEFAULT '',
  `xpos` varchar(5) NOT NULL DEFAULT '',
  `ypos` varchar(5) NOT NULL DEFAULT '',
  `width` varchar(5) NOT NULL DEFAULT '',
  `height` varchar(5) NOT NULL DEFAULT '',
  `style_type` varchar(10) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `templates`
--

INSERT INTO `templates` (`id`, `name`, `block`, `type`, `xpos`, `ypos`, `width`, `height`, `style_type`) VALUES
(1, 'standard', '1', 'top', '0', '0', '800', '100', ''),
(2, 'standard', '2', 'link', '0', '100', '100', '800', 'leftside1'),
(3, 'standard', '3', 'general', '100', '100', '100', '100', ''),
(4, 'standard', '4', 'general', '200', '100', '100', '100', ''),
(5, 'standard', '5', 'general', '100', '200', '200', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE `videos` (
  `id` int(11) NOT NULL,
  `filename` varchar(120) DEFAULT NULL,
  `title` varchar(60) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(60) NOT NULL,
  `playlist` int(11) NOT NULL,
  `playlist_title` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blocks`
--
ALTER TABLE `blocks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `block_types`
--
ALTER TABLE `block_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `smugmug`
--
ALTER TABLE `smugmug`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `temp`
--
ALTER TABLE `temp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `templates`
--
ALTER TABLE `templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blocks`
--
ALTER TABLE `blocks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=300;
--
-- AUTO_INCREMENT for table `block_types`
--
ALTER TABLE `block_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `smugmug`
--
ALTER TABLE `smugmug`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22989;
--
-- AUTO_INCREMENT for table `temp`
--
ALTER TABLE `temp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `templates`
--
ALTER TABLE `templates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
